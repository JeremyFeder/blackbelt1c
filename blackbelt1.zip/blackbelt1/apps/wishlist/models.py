from __future__ import unicode_literals
from django.db import models
from django.utils.timezone import now

class ItemManager(models.Manager):
    def update(self, id, form_info):
        item = Item.objects.get(id=id)
        item.itm = form_info['itm']
        item.addby = form_info['addby']
        item.dateadd = form_info['dateadd']
        item.save()


class Item(models.Model):
    itm = models.CharField(max_length=45)
    addby = models.CharField(max_length=200)
    dateadd = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ItemManager()
