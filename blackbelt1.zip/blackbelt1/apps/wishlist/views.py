from django.shortcuts import render, redirect
from models import Item

def users(request):
    if request.method == "POST":
        return create(request)

    return index(request)

def users_w_id(request, id):
    if request.method == "POST":
        return update(request, id)
    return show(request, id)

def index(request):
    # Retrieve all items to display in template
    items = Item.objects.all()
    return render(request, 'wishlist/index.html', { 'items': items })

# POST /users
def create(request):
    Item.objects.create(itm=request.POST['itm'], addby=request.POST['addby'], dateadd=request.POST['dateadd'])
    return redirect('/wishlist')


# GET /users/new
def new(request):
    return render(request, 'wishlist/new.html')

# GET /users/<id>
def show(request, id):
    item = Item.objects.get(id=id)
    return render(request, 'wishlist/show.html', { 'item' : item })

def update(request, id):
    Item.objects.update(id, request.POST)
    return redirect('/wishlist')


# POST /users/<id>/destroy
def destroy(request, id):
    Item.objects.get(id=id).delete()
    return redirect('/wishlist')
